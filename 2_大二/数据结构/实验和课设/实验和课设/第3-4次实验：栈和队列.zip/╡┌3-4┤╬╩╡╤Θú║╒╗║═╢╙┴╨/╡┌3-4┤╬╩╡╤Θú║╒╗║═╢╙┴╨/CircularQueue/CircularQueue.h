#include "stdlib.h"

#define OVERFLOW -1
#define OK 1
#define ERROR 0    
#define TRUE 2
#define FALSE -2

typedef char ElemType;
typedef struct {
   ElemType  *elem;  // �洢�ռ�Ļ�ַ
   int front;        // ��ͷλ��
   int rear;         // ��βλ�ָ꣬ʾ��βԪ�ص���һλ��
   int maxSize;      // ��󳤶�
} SqQueue;



typedef int Status;

Status InitQueue_Sq(SqQueue& Q, int size);
Status EnQueue_Sq(SqQueue& Q, ElemType e);
Status DeQueue_Sq(SqQueue& Q, ElemType& e);
Status QueueEmpty_Sq(SqQueue Q);




