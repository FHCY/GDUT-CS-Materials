#define OVERFLOW -1
#define OK 1
#define ERROR 0    
#define TRUE 2
#define FALSE -2

typedef int ElemType;
typedef struct LSNode {
    ElemType data;    // ������
    struct LSNode* next;    // ָ����
} LSNode, * LStack;    // ������ջ����



typedef int Status;

Status InitStack_LS(LStack& S);
Status Push_LS(LStack& S, ElemType e);
Status Pop_LS(LStack& S, ElemType& e);




