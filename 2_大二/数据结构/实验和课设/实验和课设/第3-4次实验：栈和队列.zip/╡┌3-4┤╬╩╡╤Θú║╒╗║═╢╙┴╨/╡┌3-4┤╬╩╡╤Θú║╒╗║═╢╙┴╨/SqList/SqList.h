#define OVERFLOW -1
#define OK 1
#define ERROR 0    
#define TRUE 2
#define FALSE -2

typedef int ElemType;
typedef struct {
    ElemType* elem;  // �洢�ռ�Ļ�ַ
    int length;       // ����
    int size;         // �洢����
    int increment;    // �洢����
} SqList;



typedef int Status;

Status InitList_Sq(SqList& S, int size, int inc);
Status GetElem_Sq(SqList L, int i, ElemType& e);
Status Append_Sq(SqList& L, ElemType e);




